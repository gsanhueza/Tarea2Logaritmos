# Tarea 2

## Integrantes
* Rodrigo Delgado
* Belisario Panay
* Gabriel Sanhueza

* Escrito en Java
* SRC de Eclipse
