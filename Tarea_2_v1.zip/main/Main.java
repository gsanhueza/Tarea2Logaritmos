package main;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {

		/**
		 * TEST 1 text = banana search = ana
		 */
		String input = "101001100$";
		Ukkonen x = new Ukkonen(input);
		Node t = x.run();

		List<Integer> resp = x.suffixStartPosition("1",t);
		if (resp != null) {
			System.out.println("El sufijo puede encontrarse en la/s posicion/nes: ");
			for (int integer : resp) {
				System.out.println(integer + " ");
			}
		} else {
			System.out.println("No se encontro el sufijo");
		}

		/**
		 * TEST 2 text = (english.short) search = book
		 */
		long initTime;
		long endTime;

		Logger logger = null;
		

		try {
			logger = new Logger("LogFile.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		String text = null;
		
		for (int k = 15; k <= 25; k++) {
			/**
			 * Recibimos un texto para procesarlo
			 */
			
			try {
				text = new String(Files.readAllBytes(Paths.get("../Texts/english.N" + k)), StandardCharsets.UTF_8);
			} catch (IOException e) {
				e.printStackTrace();
			}
	
			String processedText = TextPreprocessor.process(text);
	
			double textLength = Math.log(processedText.length()) / Math.log(2.0);
			logger.log("El texto procesado es de aprox. N = 2^" + Math.round(textLength) + " caracteres");
			System.out.println("El texto procesado es de aprox. N = 2^" + Math.round(textLength) + " caracteres");
	
			/**
			 * Construimos el SuffixTree
			 */
			Ukkonen st = new Ukkonen(processedText);
	
			initTime = System.currentTimeMillis();
			Node root = st.run();
			endTime = System.currentTimeMillis();

			System.out.println("Tiempo de construcción de SuffixTree = " + (endTime - initTime) + "\n");
			logger.log("Tiempo de construcción de SuffixTree = " + (endTime - initTime));
	
			/**
			 * Elegimos N/10 palabras del texto al azar para buscarlas
			 */
			List<String> toSearch = new ArrayList<String>();
			String splittedText[] = processedText.split(" ");
	
			for (int i = 0; i < splittedText.length / 10; i++) {
				toSearch.add(splittedText[(int) (Math.random() * splittedText.length)]);
			}
	
			/**
			 * Buscamos las palabras en el Suffix Tree
			 */
			
			long sumTime = 0;
			int sumWord = 0;
			
			for (String word : toSearch) {
				if (word.length() != 0) {
	
					int wordLength = word.length();
					//logger.log("Palabra buscada: " + word);
					sumWord += wordLength;
					//logger.log("Largo de la palabra: " + wordLength);
					initTime = System.nanoTime();
					int ocurrences = st.countSuffixOcurrences(word, root);
					endTime = System.nanoTime();
					long deltaTime = endTime - initTime;
					sumTime += deltaTime;
					//logger.log("Tiempo de búsqueda: " + deltaTime);
					//logger.log("Número de ocurrencias: " + ocurrences);
	
					//logger.log();
				}
			}
			
			double averageTime = ((double) sumTime) / toSearch.size();
			double patternLength = ((double) sumWord) / toSearch.size();
			
			logger.log("Tiempo promedio de búsqueda: " + averageTime);
			logger.log("Largo promedio del patrón: " + patternLength);
			logger.log();
		}
		logger.terminate();
	}
		
}
